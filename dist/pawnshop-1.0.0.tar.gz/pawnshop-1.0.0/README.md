# Pawnshop
A simple chess package for python written solely as hobby project. I've also written a GUI with networking socket capabilities (add link here) and might create some AI furter down the line.

The package also includes a 4-player mode although the ruleset is unchanged from the classic game, Checkmate -> Game Over!
## Background
This is my first real project to scale (> 1000 lines of code) and the first to be published to PyPi (add link here).

The project has certainly been a product of time with other hobby projects and school often taking priority. This along with multiple mid-project large scale refractorizations, reconsiderations and laziness should explain the unorganized codebase.

Needless to say, I've attempted to document the code well and create a proper package that I can "proudly" publish. I even wrote a simple and small unit test (using pytest(link here)), although I still  don't recommend anyone to continue developing or using this outside of simple projects like this. There are definitely better alternatives out there.

Some central documentation and usage examples would have been beneficial, but as of now I just want to continue with other projects and leave this as finished for the time being.
